import base64
import json
import logging
from datetime import datetime
import functions_framework

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@functions_framework.cloud_event
def handle_alert(cloud_event):
    """
    Cloud Run Function (2nd gen) triggered by Pub/Sub to handle alerts from Cloud Monitoring.
    
    In MVP: Logs alert details + simulates email notification
    Production: Would integrate with SendGrid/PagerDuty/ServiceNow APIs
    """
    
    # Decode Pub/Sub message from CloudEvent
    message_data = base64.b64decode(cloud_event.data["message"]["data"]).decode('utf-8')
    alert_payload = json.loads(message_data)
    
    # Extract alert information
    incident_id = alert_payload.get('incident', {}).get('incident_id', 'unknown')
    condition_name = alert_payload.get('incident', {}).get('condition_name', 'unknown')
    summary = alert_payload.get('incident', {}).get('summary', 'No summary')
    state = alert_payload.get('incident', {}).get('state', 'unknown')
    severity = alert_payload.get('incident', {}).get('severity', 'unknown')
    policy_name = alert_payload.get('incident', {}).get('policy_name', 'unknown')
    
    # Log structured alert data
    alert_log = {
        "timestamp": datetime.utcnow().isoformat(),
        "incident_id": incident_id,
        "policy_name": policy_name,
        "condition": condition_name,
        "state": state,
        "severity": severity,
        "summary": summary,
        "message": "🚨 SRE Alert Received",
        "action": "logged_to_cloud_logging"
    }
    
    logger.info(f"Alert Handler: {json.dumps(alert_log, indent=2)}")
    
    # Simulate sending email notification
    email_notification = {
        "timestamp": datetime.utcnow().isoformat(),
        "action": "mock_email_sent",
        "recipient": "ops-team@example.com",
        "subject": f"🚨 ALERT: {policy_name}",
        "body": f"Incident ID: {incident_id}\nCondition: {condition_name}\nState: {state}\nSeverity: {severity}\n\n{summary}",
        "incident_id": incident_id
    }
    
    logger.info(f"📧 Mock Email Notification: {json.dumps(email_notification, indent=2)}")
    
    # MVP: Log the alert and simulate email
    # Production would do:
    # - Send email via SendGrid: sendgrid.send_email(to='ops@example.com', subject=..., body=...)
    # - Create PagerDuty incident: pagerduty.create_incident(alert_payload)
    # - Create ServiceNow ticket: servicenow.create_incident(alert_log)
    # - Post to Slack channel: slack.post_message(channel='#alerts', text=...)
    
    logger.info(f"✅ Alert {incident_id} processed successfully")
